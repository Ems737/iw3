package ar.edu.iua.iw3.controllers;

public class BaseRestController {

}
